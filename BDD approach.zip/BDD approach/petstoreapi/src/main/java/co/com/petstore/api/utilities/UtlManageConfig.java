package co.com.petstore.api.utilities;

import net.serenitybdd.core.environment.EnvironmentSpecificConfiguration;
import net.thucydides.core.configuration.SystemPropertiesConfiguration;
import net.thucydides.core.util.EnvironmentVariables;
import net.thucydides.core.util.SystemEnvironmentVariables;
import net.thucydides.core.webdriver.Configuration;

public class UtlManageConfig {

	@SuppressWarnings("rawtypes")
	private static final Configuration CONFIGURATION =
			new SystemPropertiesConfiguration(SystemEnvironmentVariables.createEnvironmentVariables());

	private static final EnvironmentVariables environmentVariables =
			CONFIGURATION.getEnvironmentVariables();

	public static final String FIND_USER_BY_USERNAME =
			EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("FindUserByUsername.service");

	public static final String CREATE_USER =
			EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("createUser.service");

	public static final String LOGIN_USER =
			EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("LoginUser.service");

	public static final String LOGOUT_USER =
			EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("LogOutUser.service");

	public static final String DELETE_USER =
			EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("DeleteUser.service");

	public static final String UPDATE_USER =
			EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("UpdateUser.service");

	public static final String ARRAY_USER =
			EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("createUserWithArray.service");

	public static final String LIST_USER =
			EnvironmentSpecificConfiguration.from(environmentVariables).getProperty("createUserWithList.service");

	private UtlManageConfig() {
		super();
	}


}