package co.com.petstore.api.endpoints;
import co.com.petstore.api.utilities.UtlManageConfig;
import org.json.simple.JSONObject;
import io.restassured.response.Response;

import co.com.petstore.api.utilities.UtlRestClient;

import java.util.HashMap;
import java.util.Map;

public class User {

    private UtlRestClient userTemplate;

    public Response FindUserByUsername (String Username){
        userTemplate = new UtlRestClient (UtlManageConfig.FIND_USER_BY_USERNAME + Username);
        return userTemplate.getRequest();
    }

    public Response CreateUser (int id, String username, String firstName, String lastName, String email, String password, String phone, int userStatus){
        userTemplate = new UtlRestClient (UtlManageConfig.CREATE_USER);
        JSONObject requestParams = new JSONObject();
        requestParams.put("id", id);
        requestParams.put("username", username);
        requestParams.put("firstName", firstName);
        requestParams.put("lastName", lastName);
        requestParams.put("email", email);
        requestParams.put("password", password);
        requestParams.put("phone", phone);
        requestParams.put("userStatus", userStatus);

        userTemplate.setBody(requestParams.toJSONString());
        return userTemplate.postRequest();

    }

    public Response LoginUser (String Username, String Password){

        String endpoint2 ="?username=" + Username + "&password=" + Password;
        userTemplate = new UtlRestClient (UtlManageConfig.LOGIN_USER + endpoint2);
        return userTemplate.getRequest();
    }

    public Response LogOutUser (){

        userTemplate = new UtlRestClient (UtlManageConfig.LOGOUT_USER);
        return userTemplate.getRequest();
    }

    public Response deleteUserByUsername (String User){
        userTemplate = new UtlRestClient (UtlManageConfig.DELETE_USER + User);
        return userTemplate.deleteRequest();
    }


    public Response UpdateUser (String user, int id2, String username2, String firstName2, String lastName2, String email2, String password2, String phone2, int userStatus2){
        userTemplate = new UtlRestClient (UtlManageConfig.UPDATE_USER + user);
        JSONObject requestUpdParams = new JSONObject();
        requestUpdParams.put("id", id2);
        requestUpdParams.put("username", username2);
        requestUpdParams.put("firstName", firstName2);
        requestUpdParams.put("lastName", lastName2);
        requestUpdParams.put("email", email2);
        requestUpdParams.put("password", password2);
        requestUpdParams.put("phone", phone2);
        requestUpdParams.put("userStatus", userStatus2);

        userTemplate.setBody(requestUpdParams.toJSONString());
        return userTemplate.putRequest();

    }

/*
    public Response CreateUserArray (){
        userTemplate = new UtlRestClient (UtlManageConfig.ARRAY_USER);

        return userTemplate.postRequest();

    }

    public Response CreateUserList (){
        userTemplate = new UtlRestClient (UtlManageConfig.LIST_USER);

        return userTemplate.postRequest();

    }
*/

}
