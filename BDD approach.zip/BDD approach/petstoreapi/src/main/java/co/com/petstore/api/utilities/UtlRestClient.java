package co.com.petstore.api.utilities;

import java.util.Map;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.response.Response;
import net.serenitybdd.rest.SerenityRest;

public class UtlRestClient {

	  private RequestSpecBuilder restRequest;
	  private Response response;

	  public UtlRestClient(String baseUrl) {
	    restRequest = new RequestSpecBuilder();
	    restRequest.setContentType("application/json");
	    restRequest.setBaseUri(baseUrl);
	  }

	  public Response getRequest() {
	    response = SerenityRest.given(restRequest.build()).get();
	    return response;
	  }

	  public Response postRequest() {
	    response = SerenityRest.given(restRequest.build()).post();
	    return response;
	  }

	  public Response putRequest() {
	    response = SerenityRest.given(restRequest.build()).put();
	    return response;
	  }

	  public Response deleteRequest() {
	    response = SerenityRest.given(restRequest.build()).delete();
	    return response;
	  }

	  public void setQueryParams(Map<String, String> parameters) {
	    restRequest.addQueryParams(parameters);
	  }

	  public void setHeader(String headerName, String headerValue) {
	    restRequest.addHeader(headerName, headerValue);
	  }

	  public void setHeaders(Map<String, String> headers) {
	    restRequest.addHeaders(headers);
	  }

	  public void setBody(String body) {
	    restRequest.setBody(body);
	  }
	}
