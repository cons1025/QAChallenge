package co.com.petstore.api.utilities;

import org.junit.Assert;
import org.junit.Assume;

import io.restassured.response.Response;


public class Assertions {

	  private static SchemaValidator schemaValidator;
	  private static final String FAILED_MSG = "Respuesta no Exitosa : ver codigo ";

	  private Assertions() {
	    super();
	  }

	  public static void assertValidAnswer(Response response, String schemaName) {
	    schemaValidator = new SchemaValidator(response, schemaName);
	    Assert.assertTrue(FAILED_MSG + response.statusCode(), response.statusCode() == 200);
	    Assert.assertTrue(
	            "Validacion de Esquema de respuesta fallida", schemaValidator.validateSchema());
	  }

	  public static void assertValidAnswer(Response response, String schemaName, int statusCode) {
	    schemaValidator = new SchemaValidator(response, schemaName);
	    Assert.assertTrue(FAILED_MSG + response.statusCode(), response.statusCode() == statusCode);
	    Assert.assertTrue(
	            "Validacion de Esquema de respuesta fallida", schemaValidator.validateSchema());
	  }

	  public static void assertValidAnswer(Response response, int statusCode) {
	    Assert.assertTrue(FAILED_MSG + response.statusCode(), response.statusCode() == statusCode);
	  }

	  public static void assertValidAnswerPrecondition(Response response) {
	    Assume.assumeTrue(
	            "Respuesta no Exitosa para el servicio : codigo " + response.statusCode(),
	            response.statusCode() == 200);
	  }

	  public static void assertValidAnswerPrecondition(Response response, int statusCode) {
	    Assume.assumeTrue(
	            "Respuesta no Exitosa para el servicio : codigo " + response.statusCode(),
	            response.statusCode() == statusCode);
	  }

	  public static void assertValueNotNull(String value) {
	    Assume.assumeTrue("Valor de variable requisito, es nulo", value != null);
	  }

	  public static void assertTrue(boolean value) {
	    Assert.assertTrue("Se retorna valor, FALSE", value);
	  }

	  public static void assertFalse(boolean value) {
	    Assert.assertFalse("Se retorna valor, TRUE", value);
	  }
}