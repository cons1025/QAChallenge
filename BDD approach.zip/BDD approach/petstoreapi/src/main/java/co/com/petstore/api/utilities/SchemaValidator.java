package co.com.petstore.api.utilities;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

import co.com.petstore.api.logs.LogPrinter;
import io.restassured.response.Response;

public class SchemaValidator {

	  private String schemaName;
	  private Response response;

	  public SchemaValidator(Response response, String schemaName) {
	    this.response = response;
	    this.schemaName = schemaName;
	  }

	  public Boolean validateSchema() {
	    LogPrinter.printLog("Validating Json Schema structure for " + schemaName + " service");
	    try {
	      response.then().body(matchesJsonSchemaInClasspath("schemas/" + schemaName + ".json"));
	      LogPrinter.printLog("Response validated with success " + response.getBody().asString());
	      return true;
	    } catch (AssertionError error) {
	      LogPrinter.printErrror(error.toString());
	      return false;
	    }
	  }
	}

