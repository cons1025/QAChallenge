package co.com.petstore.api.stepDefinitios;
import co.com.petstore.api.endpoints.User;
import co.com.petstore.api.utilities.Assertions;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.cucumber.java.en.And;
import io.restassured.response.Response;
public class UserSteps {

    User userEndPoint;
    Response userResponse;

    int id, id2;
    String username, username2;
    String firstName, firstName2;
    String lastName, lastName2;
    String email, email2;
    String password, password2;
    String phone, phone2;
    int userStatus, userStatus2;

    String Username;
    String Password;


    @Given("the pet store API is available")
    public void initApi (){
        userEndPoint = new User();
    }

    @When("a user search for the (.*) in the pet store")
    public void getUserbyName (String username){

        userResponse = userEndPoint.FindUserByUsername(username);

    }

    @Then("pet store API retuns user details")
    public void validateResponse (){
        Assertions.assertValidAnswerPrecondition(userResponse,200);


    }

    @And("admin user has a user request with id (.*)")
    public void getId (int id){
        this.id = id;
    }

    @And("admin user has a user request with username (.*)")
    public void getUsername (String username){
        this.username = username;
    }

    @And("admin user has a user request with firstName (.*)")
    public void getFirstName (String firstName){
        this.firstName = firstName;
    }

    @And("admin user has a user request with lastName (.*)")
    public void getLastName (String lastName){
        this.lastName = lastName;
    }

    @And("admin user has a user request with email (.*)")
    public void getEmail (String email){
        this.email = email;
    }

    @And("admin user has a user request with password (.*)")
    public void getPassword (String password){
        this.password = password;
    }

    @And("admin user has a user request with phone (.*)")
    public void getPhone (String phone){
        this.phone = phone;
    }

    @And("admin user has a user request with userStatus (.*)")
    public void getUserStatus (int userStatus){
        this.userStatus = userStatus;
    }

    @When("an admin submit  the user request")
    public void submitRequest (){

        userResponse = userEndPoint.CreateUser(id, username, firstName, lastName, email, password, phone, userStatus);

    }

    @Then("pet store API creates user with details")
    public void validateCreateResponse (){

        Assertions.assertValidAnswerPrecondition(userResponse,200);

    }


    @And("user has a Username (.*)")
    public void getUsuario (String Username){
        this.Username = Username;
    }

    @And("user has a Password (.*)")
    public void getPass (String Password){
        this.Password = Password;
    }

    @When("a user submit the credentials on the pet store")
    public void getLogin () {

        userResponse = userEndPoint.LoginUser(Username, Password);
    }

    @Then("pet store API logged in the pet store user")
    public void validateLogin (){
        Assertions.assertValidAnswerPrecondition(userResponse,200);


    }

    @When("a user submit the log out option on the pet store")
    public void getLogOut () {

        userResponse = userEndPoint.LogOutUser();
    }

    @Then("pet store API logged out user from the pet store user")
    public void validateLogOut (){
        Assertions.assertValidAnswerPrecondition(userResponse,200);


    }

    @When("a user submits delete request for the (.*) in the pet store")
    public void deleteUser (String user){

        userResponse = userEndPoint.deleteUserByUsername(user);

    }

    @Then("pet store API deletes user")
    public void validateDelete (){
        Assertions.assertValidAnswerPrecondition(userResponse,200);


    }

    @And("User has a user wants to update id information with (.*)")
    public void getId2 (int id2){
        this.id2 = id2;
    }

    @And("User has a user wants to update username with (.*)")
    public void getUsername2 (String username2){
        this.username2 = username2;
    }

    @And("User has a user wants to update firstName with (.*)")
    public void getFirstName2 (String firstName2){
        this.firstName2 = firstName2;
    }

    @And("User has a user wants to update lastName with (.*)")
    public void getLastName2 (String lastName2){
        this.lastName2 = lastName2;
    }

    @And("User has a user wants to update email with (.*)")
    public void getEmail2 (String email2){
        this.email2 = email2;
    }

    @And("User has a user wants to update password (.*)")
    public void getPassword2 (String password2){
        this.password2 = password2;
    }

    @And("User has a user wants to update phone with (.*)")
    public void getPhone2 (String phone2){
        this.phone2 = phone2;
    }

    @And("User has a user wants to update userStatus with (.*)")
    public void getUserStatus2 (int userStatus2){
        this.userStatus2 = userStatus2;
    }

    @When("a user submit information for the (.*) in the pet store")
    public void submitUpdate (String user){

        userResponse = userEndPoint.UpdateUser(user, id2, username2, firstName2, lastName2, email2, password2, phone2, userStatus2);

    }

    @Then("pet store API updates user with details")
    public void validateUpdateResponse (){

        Assertions.assertValidAnswerPrecondition(userResponse,200);

    }




}
