package co.com.petstore.api.Runner;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;


@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        features = "src/test/resources",
        glue = {"co.com.petstore.api.stepDefinitios"})
public class UserRunner {


}
